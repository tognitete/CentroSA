<?php $__env->startSection('content'); ?>


  <?php echo $__env->make('Layout.partials._nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
<form action="" method="GET">
  <?php echo e(csrf_field()); ?>


<div class="eng_obj">
<div class="container" style="width:1000px">
    <div class="well">


      
      
        <div class="row">
        <div class="col-md-offset-2 col-md-8">
        <h1 class="title text-center">CHOIX FACTURE</h1>

    </div>
     
        </div>
    <br/><br/><br/>
    

      <div class="row">
            <div class="col-md-offset-1 col-md-1" > 
            <div class="form-group">
            <a href="/SFAVANCE?date=<?php echo e($date); ?>&num=<?php echo e($num); ?>&montant=<?php echo e($montant); ?>&avance=<?php echo e($avance); ?>&id=<?php echo e($id); ?>" class="btn btn-primary" style="height:100px;width:400px;"><h1 style="height:100px;">FACTURE AVANCE</h1></a>  
           </div>   
        </div>
        <div class="form-group">
        <div class="col-md-offset-4 col-md-2">
            
           <a href="/SFSOLDE?date=<?php echo e($date); ?>&num=<?php echo e($num); ?>&montant=<?php echo e($montant); ?>&avance=<?php echo e($avance); ?>&id=<?php echo e($id); ?>" class="btn btn-primary" style="height:100px;width:400px;"><h1 style="height:100px;">FACTURE DE SOLDE</h1></a>  

          </div>
      </div>
    </div>
       <br/><br/>
      

      
      <div class="row">
        <br/>
        <div class="col-md-offset-0 col-md-2">
        <a href="javascript:history.go(-1);">Annuler</a>
      </div>
    </div>

   
        
        
           
           
          
      </div>
    </div>
</div>
<?php echo $__env->make('Layout/partials/_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>