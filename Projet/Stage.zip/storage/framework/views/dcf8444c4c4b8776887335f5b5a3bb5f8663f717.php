<?php $__env->startSection('content'); ?>
<div class="eng_obj">
<div class="container">
    <div class="well">
        <div class="row">
        <div class="col-md-offset-3 col-md-10">
        <h1 class="title">ENREGISTRMENT D'OBJET</h1>

    </div>
     
        </div>

        <div class="row">
            <div class="col-md-offset-2 col-md-8"> 
            <div class="form-group">
              <label for="designation">Deignation</label>
              <input type="text" name="designation" id="designation" class="form-control" placeholder="Nom de l'objet">

            </div>
        </div>
    </div>

    <div class="row">
            <div class="col-md-offset-2 col-md-6"> 
            <div class="form-group">
              <label for="ute">UTE</label>
              <select id="disabledSelect" class="form-control">
                    <option>UTE</option>
              </select>
                </div>
        </div>
        <div class=" col-md-2">
            <br/>
           <a href="/UTE"  style="height:40px"class="btn btn-primary form-control">Nouvelle UTE?</a>

          </div>
      </div>
      <div class="row">
        <br/>
        <div class="col-md-offset-5 col-md-2">
        <div class="form-group">
           <button class="btn btn-success ">ENREGISTRER &raquo</button>
           </div>
          </div>
      </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>