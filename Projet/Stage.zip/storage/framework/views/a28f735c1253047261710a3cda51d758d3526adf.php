<?php $__env->startSection('content'); ?>

<form action="" method="POST">
  <?php echo e(csrf_field()); ?>

<?php echo $__env->make('Layout.partials._nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="eng_obj">
<div class="container">
    <div class="well">


      
      
        <div class="row">
        <div class="col-md-offset-4 col-md-4">
        <h1 class="title">DESTINATION</h1>

    </div>
     
        </div>

        <div class="row">
            <div class="col-md-offset-2 col-md-8"> 
            <div class="form-group">
              <label for="objet">Nombre de destination</label>
             
             
           <input type="text" name="nb_d" id="nb_d" class="form-control" placeholder="Nombre de destination">   
              
            </div>
        </div>
        
       <br/>
        <div class="col-md-2">
        <div class="form-group">
           <input type="submit" style="height:42px;" name="lieu_eng" class="btn btn-success " value="SUIVANT &raquo">
          
           </div>
          </div>
          
        <div class="row">
            <div class="col-md-offset-2 col-md-6"> 
            <div class="form-group">
              <p><?php echo $errors->first('nb_d','<span class="help-block err">:message</span>'); ?></p>
            </div>
          </div>
        </div>

      </div>
       <br/><br/>
      

      
      <div class="row">
        <br/>
        <div class="col-md-offset-0 col-md-2">
        <a href="javascript:history.go(-1);">Annuler</a>
      </div>
    </div>

   
        
        
           
           
          
      </div>
    </div>
</div>
<input type="hidden" value="<?php echo e($user); ?>">
<?php echo $__env->make('Layout/partials/_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>