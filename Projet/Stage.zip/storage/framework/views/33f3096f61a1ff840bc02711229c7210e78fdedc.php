<?php $__env->startSection('content'); ?>


  <?php echo $__env->make('Layout.partials._nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
<form action="" method="GET">
  <?php echo e(csrf_field()); ?>


<div class="eng_obj">
<div class="container">
    <div class="well">


      
      
        <div class="row">
        <div class=" col-md-12">
        <h1 class="title text-center">COMMANDE DEJA REGLE POUR LE FOURNISSEUR <span class="orange"><?php echo e($frs); ?></span></h1>

    </div>
     
        </div>
    <br/><br/><br/>
   
 
      <div class="row">
        <?php for($i=0;$i<count($num);$i++): ?>
        
          <div class="  col-md-4" style="height:200px">
           
        <?php if((($i+1)%2)==0): ?>    
         <div style="border: 2px solid #1c75c8;height:220px;padding: 3px; background-color:rgb(196,196,196); -moz-border-radius-topleft: 5px; -moz-border-radius-topright: 5px; -moz-border-radius-bottomright: 5px; -moz-border-radius-bottomleft: 5px;" id="banniere" onmouseover="dwn(<?php echo e($i+1); ?>)" onmouseout="outdwn(<?php echo e($i+1); ?>)">
        
        <?php else: ?>
        <div style="border: 2px solid #1c75c8;height:220px;padding: 3px; background-color:rgb(241,221,152); -moz-border-radius-topleft: 5px; -moz-border-radius-topright: 5px; -moz-border-radius-bottomright: 5px; -moz-border-radius-bottomleft: 5px;" id="banniere" onmouseover="dwn(<?php echo e($i+1); ?>)" onmouseout="outdwn(<?php echo e($i+1); ?>)">
        <?php endif; ?>
<span class="title">BC N&deg</span><span class="orange"><?php echo e($num[$i]); ?></span><br/><br/>
<span class="title">Materiaux Commande:</span><span class="orange"><?php echo e($desi[$i]); ?></span><br/><br/>
<span class="title">Montant Total:</span><span class="orange"><?php echo e($montant[$i]); ?></span><br/><br/>
<span class="title">Avance:</span> <span class="orange"><?php echo e($taux[$i]); ?>%</span> soit <input type="text" disabled="disabled" value="<?php echo e($cal[$i]); ?>"><br/><br/>
<?php if($observation[$i]!=null): ?>
<span class="title">observations:</span><span class="orange"><?php echo $observation[$i]; ?></span>
 <?php endif; ?>
 <div id="<?php echo e($i+1); ?>" class="description">
          Telechargement...
          <input type="submit" class="btn btn-primary dwn" value="Telecharger">
</div>
</div>


        </div>
         <?php if(($i+1)%3==0): ?>
     
         </div>
         <div class="row">   
      <br/><br/>
   


      <?php endif; ?>
     
 <?php endfor; ?>      

         
    
        


          
         
</div>
<br/><br/><br/><br/><br/><br/>

      

      
      <div class="row">
        <br/>
        <div class="col-md-offset-0 col-md-2">
        <a href="javascript:history.go(-1);">Annuler</a>
      </div>
    </div>

   
        
        
           
           
          
      </div>
    </div>
</div>
<?php echo $__env->make('Layout/partials/_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('Layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>