<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('DesignationObjet.store')); ?>" method="POST">
  <?php echo e(csrf_field()); ?>

<?php echo $__env->make('Layout.partials._nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="eng_obj">
<div class="container">
    <div class="well">


<img src="/images/logo.png" style="width:100px;margin-left:-20px" alt="logo de CENTRO" class="img-rounded">


        <div class="row">
        <div class="col-md-offset-1 col-md-10 text-center">
        <h1 class="title">ENREGISTRMENT D'UNE DESIGNATION D'OBJET</h1>

    </div>
     
        </div>

        <div class="row">
            <div class="col-md-offset-2 col-md-6"> 
            <div class="form-group">
              <label for="objet">OBJET</label>
              <select id="objet" name="objet" class="form-control">
                <option></option>
                <?php if(!$objet->isEmpty()): ?>
                <?php $__currentLoopData = $objet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ob): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e(selection_ute($ob->DESIGNATION_UTE,old('objet'))); ?>><?php echo e($ob->NOM_OBJET); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
               
                <?php endif; ?>
              </select>
              <p><?php echo $errors->first('objet','<span class="help-block err">:message</span>'); ?></p>
                </div>
        </div>
        <div class=" col-md-2">
            <br/>
           <a href="<?php echo e(route('objet.create')); ?>"  style="height:40px"class="btn btn-primary form-control">Nouvel OBJET?</a>

          </div>
      </div>
     
              
        <div class="row">
            <div class="col-md-offset-2 col-md-8"> 
            <div class="form-group">
              <label for="designation_objet">Deignation</label>
              <input type="hidden" name="url" value="<?php echo e($url); ?>">
              <input type="text" name="designation_objet" id="designation_objet" class="form-control" value="<?php echo e(old('designation_objet')? old('designation_objet'):''); ?>" placeholder="Designation">
              <p><?php echo $errors->first('designation_objet','<span class="help-block err">:message</span>'); ?></p>
            </div>
        </div>
    </div>

    <div class="row">
            <div class="col-md-offset-2 col-md-6"> 
            <div class="form-group">
              <label for="ute">UTE</label>
              <select id="designation_ute" name="designation_ute" class="form-control">
                <option></option>
                <?php if(!$ute->isEmpty()): ?>
                <?php $__currentLoopData = $ute; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $utes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e(selection_ute($utes->DESIGNATION_UTE,old('designation_ute'))); ?>><?php echo e($utes->DESIGNATION_UTE); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
               
                <?php endif; ?>
              </select>
              <p><?php echo $errors->first('designation_ute','<span class="help-block err">:message</span>'); ?></p>
                </div>
        </div>
        <div class=" col-md-2">
            <br/>
           <a href="<?php echo e(route('ute.create')); ?>"  style="height:40px"class="btn btn-primary form-control">Nouvelle UTE?</a>

          </div>
      </div>
      <div class="row">
        <br/>
        <div class="col-md-offset-5 col-md-2">
        <div class="form-group">
           <input type="submit" name="obj_eng" class="btn btn-success "  value="ENREGISTRER &raquo">

           </div>
          </div>
      </div>
      <div class="row">
        <br/>
        <div class="col-md-offset-0 col-md-2">
        <a href="javascript:history.go(-1);">Annuler</a>
      </div>
    </div>
</div>
<?php echo $__env->make('Layout/partials/_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>