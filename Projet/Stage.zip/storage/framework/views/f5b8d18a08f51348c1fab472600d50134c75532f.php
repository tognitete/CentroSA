<?php
use App\Bon_Commande\Designation;

if(isset($_GET['rech']) AND !empty($_GET['rech'])){
  $motclef=$_GET['rech'];
  
      $motclef='%'.$motclef.'%';
    
    

    $list_designation=Designation::selectRaw('designations.NOM_DESIGNATION_OBJET,utes.DESIGNATION_UTE')
                                 ->Where('designations.NOM_DESIGNATION_OBJET','like',$motclef)
                                 ->join('utes','utes.ID_UTE','=','designations.ID_UTE')
                                 ->get();
                                
      
  
}else{
  $list_designation=Designation::selectRaw('designations.NOM_DESIGNATION_OBJET,utes.DESIGNATION_UTE')
                                 ->join('utes','utes.ID_UTE','=','designations.ID_UTE')
                                 ->get();
}

?>

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
 
 $("#delais").keyup(function(){

  
  var recherche = $(this).val();
  var data = 'motclef='+ recherche;
  if(recherche.length>0){

        
    $.ajax({
      type: "GET",
      url:"<?php echo e(route('fournisseur.create')); ?>",
      data : data,
      success:function(server_response){

        
    }
    });

    
  }

 });
});
</script>


<?php $__env->startSection('content'); ?>


  <?php echo $__env->make('Layout.partials._nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="eng_obj">
<div class="container">
    <div class="well">


    

        <div class="row">
        <div class="col-md-offset-1 col-md-10">
          <img src="/images/logo.png" style="width:100px;margin-left:-80px" alt="logo de CENTRO" class="img-rounded">
        <h1 class="title" id="haut">BON DE COMMANDE N&deg<?php echo e($num); ?>/PDG/DAA/CAA/BR/<?php echo e($y); ?></h1>


    </div>

     
        </div>
        <div class="row">
        <div class="col-md-offset-1 col-md-push-7">
          <a href="#bas"><img src="/images/bas.png" style="width:100px;margin-left:-80px"  class="pull-right"></a>
        
        

    </div>

     
        </div>
      <br/><br/>
      
      
      
      
        <br/><br/><br/>

        <div class="row">
          <div class="col-md-7" style="">
            <h1 class="text-center orange title">DESIGNATIONS</h1>
             <br/><br/><br/>
             <form action="" method="GET" id="appro">
              <?php if(isset($user)){?>
              <input type="hidden" id="user" name="user" value="<?php echo e($user); ?>">
              <?php } ?>
<div class=" col-md-offset-5 col-md-4" > <input type="search" value="<?php echo e(old('rech')); ?>" style="height:35px;width:195px" name="rech"></div>
    <input type="submit"class="btn btn-primary " style="height:35px" value="FILTRER" >
    <button class="btn btn-primary" type="submit" style="height:35px" ><img src="/images/r.png" style="width:30px"></button>

          <table class="table table-condensed" style="color:black" name="tableau">
  <tr>
       
       <th class="blue" >Designation</th>
       <th class="blue" style="width:130px">UTE</th>
       <!--<th class="blue">Prix Unit.</th>-->
       <th class="blue">Quantite</th>
       <th class="blue">Prix Unit.</th>
       <th class="blue">Choix</th>
   </tr>
       <?php if(!$list_designation->isEmpty()): ?>
       <?php $i=0 ?>
       <?php $__currentLoopData = $list_designation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $des): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <?php $i++ ?>
   <tr>
       
       <td><?php echo e($des->NOM_DESIGNATION_OBJET); ?></td>
       <td><?php echo e($des->DESIGNATION_UTE); ?></td>
    
       <td><input type="text" class="form-control" disabled="disabled" style="width:100px" name="<?php echo e($des->NOM_DESIGNATION_OBJET); ?>" 
        id="<?php echo e($des->NOM_DESIGNATION_OBJET); ?>" onKeyUp="key(<?php echo e($i); ?>,'<?php echo e($des->NOM_DESIGNATION_OBJET); ?>')" ></td>
       <td><input type="text" class="form-control" disabled="disabled" style="width:100px" name="<?php echo e($i); ?>" id="<?php echo e($i); ?>"></td>
       <td>
        <label class="checkbox-inline">
       <input type="checkbox" id="option" name="option"  value="<?php echo e($des->NOM_DESIGNATION_OBJET); ?>" onclick="degrise()">
        </label>
       </td>
   </tr>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <?php else: ?>
        <td>Aucun Résultat</td>

       <?php endif; ?>
 
          </table>

          <div>
           <a href="<?php echo e(route('DesignationObjet.create')); ?>" class="btn btn-primary btn btn-block" style="width:510px;margin-left:20px">
            Nouvelle Designation?</a>
           </div>

        </div>
          </form> 

          <form action="<?php echo e(route('BonCommande.store')); ?>" method="POST" onsubmit="sub(<?php echo e($i); ?>)" id="appro">
  <?php echo e(csrf_field()); ?>

          <div class="col-md-5">
            <br/><br/><br/><br/><br/><br/>
            <div class="row">
            <div class="col-md-offset-2 col-md-8 col-md-push-2"> 
            <div class="form-group">
              <label for="objet" class="orange">Objet</label>
              <input type="text" name="objet" id="objet" class="form-control" >
              <p><?php echo $errors->first('objet','<span class="help-block err">:message</span>'); ?></p> 
                </div>
        </div>
      </div>
      
             <div class="row">
            <div class="col-md-offset-2 col-md-8  col-md-push-2"> 
            <div class="form-group">
              <label for="type_commande" class="orange">Type de Commande</label>
              <select id="type_commande" name="type_commande" class="form-control" style="width:170px" onchange="avance()">
                <option></option>
                 <?php $__currentLoopData = $type_commande; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t_cmde): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option><?php echo e($t_cmde->DESIGNATION_TYPE_COMMANDE); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <p><?php echo $errors->first('typ_cmde','<span class="help-block err">:message</span>'); ?></p>
            </div>
           
            </div>
          </div>
           
        <div class="row">
            <div class="col-md-offset-2 col-md-6  col-md-push-2"> 
            <div class="form-group">
              <label class="orange" for="taux_avance">Taux Avance</label>
               <input type="text" name="taux_avance" id="taux_avance" value="<?php echo e(old('taux_avance')? old('taux_avance') :''); ?>" class="form-control" 
               placeholder="%" disabled="disabled">
               <p><?php echo $errors->first('taux_avance','<span class="help-block err">:message</span>'); ?></p>
            </div>
          </div>
        </div>
       
            <div class="row">
            <div class="col-md-offset-2 col-md-5  col-md-push-2 "> 
            <div class="form-group">
              <label for="nom_fournisseur" class="orange">Fournisseur</label>
              <select id="nom_fournisseur" name="nom_fournisseur" class="form-control" style="width:180px" >
                <option></option>
                <?php $__currentLoopData = $fournisseur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option><?php echo e($frs->NOM_FRS); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <p><?php echo $errors->first('nom_fournisseur','<span class="help-block err">:message</span>'); ?></p>
            </div>
        </div>
        <div class="col-md-offset-2 col-md-3">
            <br/>
           
            <a href="<?php echo e(route('fournisseur.create')); ?>"  style="height:40px;margin-left:9px"class="btn btn-primary form-control" >Nouveau?</a>
          
          

          </div>
        
    </div>

      <div class="row">
            <div class="col-md-offset-2 col-md-8 col-md-push-2"> 
            <div class="form-group">
              <label for="delais" class="orange">Délais</label>
              <input type="text" name="delais"  class="form-control" >
              <p><?php echo $errors->first('delais','<span class="help-block err">:message</span>'); ?></p> 
                </div>
        </div>
      


      </div>
    
     <?php for($i=1;$i<=$nb_d;$i++): ?>  
    <div class="row">
            <div class="col-md-offset-2 col-md-8 col-md-push-2"> 
            <div class="form-group">
              <label for="destination" class="orange">Destination <?php echo e($i); ?></label>
              <input type="text" name="destination<?php echo e($i); ?>" id="destination<?php echo e($i); ?>" value="<?php echo e(old('destination'.$i)); ?>" required class="form-control" >
              <p><?php echo $errors->first('destination$i','<span class="help-block err">:message</span>'); ?></p> 
                </div>
        </div>
      


      </div>
      <?php endfor; ?>
     
     
      
            <div class="row">
            <div class="col-md-offset-2 col-md-5  col-md-push-2 "> 
            <div class="form-group">
              <label for="lieu" class="orange">Lieu</label>
              <select id="lieu" name="lieu" class="form-control" style="width:180px" >
                <option></option>
                <?php $__currentLoopData = $lieu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option><?php echo e($l->DESIGNATION_LIEU); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <p><?php echo $errors->first('lieu','<span class="help-block err">:message</span>'); ?></p>
            </div>
        </div>
        <div class="col-md-offset-2 col-md-3">
            <br/>
           <a href="<?php echo e(route('lieu.create')); ?>"  style="height:40px;margin-left:9px"class="btn btn-primary form-control">Nouveau?</a>

          </div>
        
    </div>
    
    <div class="row">
            <div class="col-md-offset-2 col-md-8 col-md-push-2"> 
            <div class="form-group">
              <label for="commentaire" class="orange">Commentaire</label>
              <textarea name="commentaire" id="commentaire" class="form-control" cols="12" rows="4"></textarea>
              <p><?php echo $errors->first('commentaire','<span class="help-block err">:message</span>'); ?></p> 
                </div>
        </div>
      </div>
        </div>
         
</div>
<div class="row">
        <div class="col-md-offset-1 col-md-push-7">
          <a href="#haut"><img src="/images/haut.png" style="width:100px;margin-left:-80px"  class="pull-right"></a>
        
        

    </div>

     
        </div>

<div class="row">
        <br/><br/><br/>

        <div class="col-md-offset-5 col-md-2">
        <div class="form-group">
           <input type="submit" name="obj_eng" class="btn btn-success "  id="bas" style="height:50px"value="ENREGISTRER &raquo">
           </div>
          </div>
      </div>
       
      <div class="row">
        <br/>
        <div class="col-md-offset-0 col-md-2">
        <a href="#">Annuler</a>
      </div>
    </div>
    </div>
</div>
<input type="hidden" id="desig" name="desig">
<input type="hidden" id="quant" name="quant">
<input type="hidden" id="unit" name="unit">
<input type="hidden" id="nb_d" name="nb_d" value="<?php echo e($nb_d); ?>">
 <?php if(isset($user)){?>
              <input type="hidden" id="user" name="user" value="<?php echo e($user); ?>">
              <?php } ?>
<?php echo $__env->make('Layout/partials/_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>