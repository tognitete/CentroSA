<html>
<head>
  <title></title>
</head>
<script type="text/javascript">
function l(){

  alert(document.getElementById('t').value);
}


</script>
<body onload="l()">
<form action="" method="POST">
<input type="text" id="t">
</form>
</body>
</html>