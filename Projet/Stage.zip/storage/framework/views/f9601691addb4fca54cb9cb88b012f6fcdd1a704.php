<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
 
 $("#delais").keyup(function(){

  
  var recherche = $(this).val();
  var data = 'motclef='+ recherche;
  if(recherche.length>0){

        
    $.ajax({
      type: "GET",
      url:"<?php echo e(route('fournisseur.create')); ?>",
      data : data,
      success:function(server_response){

        
    }
    });

    
  }

 });
});
</script>


<?php $__env->startSection('content'); ?>


  <?php echo $__env->make('Layout.partials._nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="eng_obj">
<div class="container">
  <div class="row">
  <div class="col-md-10" style="width:90%">
    <div class="well">


    

        <div class="row">
        <div class="col-md-offset-1 col-md-10">
          <img src="/images/logo.png" style="width:100px;margin-left:-80px" alt="logo de CENTRO" class="img-rounded">
        <h1 class="title text-center" id="haut">BON DE COMMANDE N&deg<?php echo e($num); ?></h1>


    </div>

     
        </div>
        
      <br/><br/>
      
      
      
      
        <br/><br/><br/>

        <div class="row">
          <div class="col-md-7" style="">
            <h1 class="text-center orange title">DESIGNATIONS</h1>
             <br/><br/><br/>
             <form action="" method="GET" id="appro">
              <?php if(isset($user)){?>
              <input type="hidden" id="user" name="user" value="<?php echo e($user); ?>">
              <?php } ?>
              


          <table class="table table-condensed" style="color:black" name="tableau">
  <tr>
       
       <th class="blue" >Designation</th>
       <th class="blue" style="width:130px">UTE</th>
       <!--<th class="blue">Prix Unit.</th>-->
       <th class="blue">Quantite</th>
       <th class="blue">Prix Unit.</th>
       <th class="blue">Choix</th>
   </tr>
       <?php if(!$list_designation->isEmpty()): ?>
       <?php $i=0 ?>
       <?php $__currentLoopData = $list_designation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $des): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <?php $i++ ?>
   <tr>
       
       <td><?php echo e($des->NOM_DESIGNATION_OBJET); ?></td>
       <td><?php echo e($des->DESIGNATION_UTE); ?></td>
    
       <td><input type="text" class="form-control" disabled="disabled" style="width:100px" name="<?php echo e($des->NOM_DESIGNATION_OBJET); ?>" 
        id="<?php echo e($des->NOM_DESIGNATION_OBJET); ?>" onKeyUp="key(<?php echo e($i); ?>,'<?php echo e($des->NOM_DESIGNATION_OBJET); ?>')" ></td>
       <td><input type="text" class="form-control" disabled="disabled" style="width:100px" name="<?php echo e($i); ?>" id="<?php echo e($i); ?>"></td>
       <td>
        <label class="checkbox-inline">
       <input type="checkbox" id="option" name="option"  value="<?php echo e($des->NOM_DESIGNATION_OBJET); ?>" onclick="degrise()">
        </label>
       </td>
   </tr>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <?php else: ?>
        <td>Aucun Résultat</td>

       <?php endif; ?>
 
          </table>

          
          <div>
           <a href="<?php echo e(route('DesignationObjet.create')); ?>" class="btn btn-primary btn btn-block" style="width:510px;margin-left:20px">
            Nouvelle Designation?</a>
           </div>

        </div>
          </form> 

          <form action="<?php echo e(route('BonCommande.store')); ?>" method="POST" onsubmit="sub(<?php echo e($i); ?>)" id="appro">
  <?php echo e(csrf_field()); ?>

          <div class="col-md-5">
            <br/><br/><br/><br/><br/><br/>
            <div class="row">
            <div class="col-md-offset-2 col-md-8 col-md-push-2"> 
            <div class="form-group">
              <label for="objet" class="orange">Objet <span class="blue">*</span></label>
              <input type="text" name="objet" id="objet" class="form-control" >
              <p><?php echo $errors->first('objet','<span class="help-block err">:message</span>'); ?></p> 
                </div>
        </div>
      </div>
      
             <div class="row">
            <div class="col-md-offset-2 col-md-8  col-md-push-2"> 
            <div class="form-group">
              <label for="type_commande" class="orange">Type de Commande <span class="blue">*</span></label>
              <select id="type_commande" name="type_commande" class="form-control" style="width:170px" onchange="avance()">
                <option></option>
                 <?php $__currentLoopData = $type_commande; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t_cmde): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option><?php echo e($t_cmde->DESIGNATION_TYPE_COMMANDE); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <p><?php echo $errors->first('typ_cmde','<span class="help-block err">:message</span>'); ?></p>
            </div>
           
            </div>
          </div>
           
        <div class="row">
            <div class="col-md-offset-2 col-md-6  col-md-push-2"> 
            <div class="form-group">
              <label class="orange" for="taux_avance">Taux Avance <span class="blue">*</span></label>
               <input type="text" name="taux_avance" required id="taux_avance" value="<?php echo e(old('taux_avance')? old('taux_avance') :''); ?>" class="form-control" 
               placeholder="%" disabled="disabled">
               <p><?php echo $errors->first('taux_avance','<span class="help-block err">:message</span>'); ?></p>
            </div>
          </div>
        </div>
       
            <div class="row">
            <div class="col-md-offset-2 col-md-5  col-md-push-2 "> 
            <div class="form-group">
              <label for="nom_fournisseur" class="orange">Fournisseur <span class="blue">*</span></label>
              <select id="nom_fournisseur" name="nom_fournisseur" class="form-control" style="width:180px" >
                <option></option>
                <?php $__currentLoopData = $fournisseur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option><?php echo e($frs->NOM_FRS); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <p><?php echo $errors->first('nom_fournisseur','<span class="help-block err">:message</span>'); ?></p>
            </div>
        </div>
        <div class="col-md-offset-2 col-md-3">
            <br/>
           
            <a href="<?php echo e(route('fournisseur.create')); ?>"  style="height:40px;margin-left:9px"class="btn btn-primary form-control" >Nouveau?</a>
          
          

          </div>
        
    </div>

      <div class="row">
            <div class="col-md-offset-2 col-md-8 col-md-push-2"> 
            <div class="form-group">
              <label for="delais" class="orange">Délais <span class="blue">*</span></label>
              <input type="text" name="delais"  class="form-control" >
              <p><?php echo $errors->first('delais','<span class="help-block err">:message</span>'); ?></p> 
                </div>
        </div>
      


      </div>
   
      

      <div class="row">
            <div class="col-md-offset-2 col-md-5  col-md-push-2 "> 
            <div class="form-group">
              <label for="destination" class="orange"><DIV>Destination <span class="blue">*</span></DIV></label>
              <select id="destination" name="destination" class="form-control" style="width:180px" >
                <option></option>
                <?php $__currentLoopData = $projet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option><?php echo e($p->DESIGNATION_PROJET); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <p><?php echo $errors->first('destination','<span class="help-block err">:message</span>'); ?></p>
            </div>
        </div>
        
        
    </div>
        

     
     
      
            <div class="row">
            <div class="col-md-offset-2 col-md-5  col-md-push-2 "> 
            <div class="form-group">
              <label for="lieu" class="orange">Lieu <span class="blue">*</span></label>
              <select id="lieu" name="lieu" class="form-control" style="width:180px" >
                <option></option>
                <?php $__currentLoopData = $lieu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option><?php echo e($l->DESIGNATION_LIEU); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <p><?php echo $errors->first('lieu','<span class="help-block err">:message</span>'); ?></p>
            </div>
        </div>
        <div class="col-md-offset-2 col-md-3">
            <br/>
           <a href="<?php echo e(route('lieu.create')); ?>"  style="height:40px;margin-left:9px"class="btn btn-primary form-control">Nouveau?</a>

          </div>
        
    </div>
    
    <div class="row">
            <div class="col-md-offset-2 col-md-8 col-md-push-2"> 
            <div class="form-group">
              <label for="commentaire" class="orange">Commentaire</label>
              <textarea name="commentaire" id="commentaire" class="form-control" cols="12" rows="4"></textarea>
              <p><?php echo $errors->first('commentaire','<span class="help-block err">:message</span>'); ?></p> 
                </div>
        </div>
      </div>
        </div>
         
</div>


<div class="row">
        <br/><br/><br/>

        <div class="col-md-offset-5 col-md-2">
        <div class="form-group">
           <input type="submit" name="obj_eng" class="btn btn-success "  id="bas" style="height:50px"value="ENREGISTRER &raquo">
           </div>
          </div>
      </div>
       
      <div class="row">
        <br/>
        <div class="col-md-offset-0 col-md-2">
        <a href="#">Annuler</a>
      </div>
    </div>
    </div>

</div>
<input type="hidden" id="desig" name="desig">
<input type="hidden" id="quant" name="quant">
<input type="hidden" id="unit" name="unit">

 <?php if(isset($user)){?>
              <input type="hidden" id="user" name="user" value="<?php echo e($user); ?>">
              <?php } ?>

              <a href="#bas"><img src="/images/bas.png" style="width:100px" class="pull-right" ></a>
</div>

<?php echo $__env->make('Layout/partials/_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>

</div>
</div>
</div>
</div>




        

     
               
          
        
        

    

</div> 
</div>
</div>    
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>