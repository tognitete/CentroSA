<?php $__env->startSection('content'); ?>

<form action="" method="POST">
  <?php echo e(csrf_field()); ?>

  <?php echo $__env->make('Layout.partials._nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="eng_obj">
<div class="container">
    <div class="well">


   <img src="/images/logo.png" style="width:100px;margin-left:-20px" alt="logo de CENTRO" class="img-rounded">

        <div class="row">
        <div class="">
        <h1 class="title text-center">FACTURE SOLDE</h1>

    </div>
     
        </div>
        
        <?php if($now): ?>
        <div class="row">
            <div class="col-md-offset-2 col-md-8"> 
            <div class="form-group">
              <label for="num_facture">Numero Facture</label>
              <input type="hidden" name="url" value="">
              <input type="text" name="num_facture" id="num_facture" class="form-control" value="<?php echo e(old('num_facture')); ?>" placeholder="Numero de la Facture">
              <p><?php echo $errors->first('num_facture','<span class="help-block err">:message</span>'); ?></p>
            </div>
        </div>
    </div>

     <div class="row">
            <div class="col-md-offset-2 col-md-8"> 
            <div class="form-group">
              <label for="objet">Objet</label>
              <input type="hidden" name="url" value="">
              <input type="text" name="objet" id="objet" class="form-control" readonly value="<?php echo e($objet); ?>" placeholder="objet">
              <p><?php echo $errors->first('objet','<span class="help-block err">:message</span>'); ?></p>
            </div>
        </div>
    </div>

     <div class="row">
            <div class="col-md-offset-2 col-md-8"> 
            <div class="form-group">
              <label for="date_facture">Date Facture</label>
              <input type="hidden" name="url" value="">
              <input type="date" name="date_facture" id="date_facture" class="form-control" value="<?php echo e(old('date_facture')); ?>" placeholder="">
              <p><?php echo $errors->first('date_facture','<span class="help-block err">:message</span>'); ?></p>
            </div>
        </div>
    </div>

    <div class="row">
            <div class="col-md-offset-2 col-md-8"> 
            <div class="form-group">
              <label for="date_reception">Date Reception Facture</label>
              <input type="date" name="date_reception" id="date_reception" value="<?php echo e(old('date_reception')); ?>" class="form-control" placeholder="">
              <p><?php echo $errors->first('date_reception','<span class="help-block err">:message</span>'); ?></p> 
                </div>
        </div>
        
      <div class="row">
        <br/>
        <div class="col-md-offset-5 col-md-2">
        <div class="form-group">
           <input type="submit" name="obj_eng" class="btn btn-success " value="ENREGISTRER &raquo">
           </div>
          </div>
      </div>
       <?php else: ?>
       <br/><br/>
      <p><img src="/images/danger.gif" style="width:55px;margin-left:100px"><span style="font-size:23px" class="orange text-center">Cette Facture ne peut être emise car la livraison date de moins de <?php echo e($delais); ?> jours</span><img src="/images/danger.gif" style="width:55px"></p>
     <br/><br/>
     <p><span style="font-size:25px" class="orange title">DATE FACTURE:</span><span style="font-size:25px"> <?php echo e($j); ?>/<?php echo e($m); ?>/<?php echo e($y); ?></span></p>
   <div class="row">
        <br/>
        <div class="col-md-offset-5 col-md-2">
        <div class="form-group">
          <a   href="/Comptabilite" name="obj_eng" class="btn btn-success text-center "  style="height:50px;width:100px;">OK</a>
           </div>
          </div>
      </div>
      <?php endif; ?>
      <input type="hidden" name="avance" value="<?php echo e($avance); ?>">
      <input type="hidden" name="num" value="<?php echo e($num); ?>">
      <input type="hidden" name="montant" value="<?php echo e($montant); ?>">
      <input type="hidden" name="date" value="<?php echo e($date); ?>">
      <input type="hidden" name="id" value="<?php echo e($id); ?>">
      
        <br/>
        <div class="col-md-offset-0 col-md-2">
        <a href="#">Annuler</a>
      </div>
    </div>
    </div>
</div>
<?php echo $__env->make('Layout/partials/_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>