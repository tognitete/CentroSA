<?php $__env->startSection('content'); ?>


  <?php echo $__env->make('Layout.partials._nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
<form action="" method="GET">
  <?php echo e(csrf_field()); ?>


<div class="eng_obj">
<div class="container" style="width:1000px">
    <div class="well">


      
      
        <div class="row">
        <div class="col-md-offset-2 col-md-8">
        <h2 class="title text-center">BON DE COMMANDE CONCERNANT LE FOURNISSEUR <span class="orange"><?php echo e($nom); ?></span></h2>

    </div>
     
        </div>
    <br/><br/><br/>
    

        <div class="row">
            <div class="col-md-offset-1 col-md-8"> 
            <div class="form-group">
        <?php if(!$bon->isEmpty()): ?>     
             
        <table class="table table-bordered" style="width:800px;color:black" >
                 
       <tr>
       
       
       <th class="blue text-center"><h4>BON DE COMMANDES </h4></th>
       <th class="blue text-center"><h4>DATE COMMANDE </h4></th>
       <th class="blue text-center"><h4>DATE PAIEMENT </h4></th>
       <th class="blue text-center"><h4>MONTANT</h4></th>
       <th style="width:50px"></th>
       
   </tr>
    
       <?php $__currentLoopData = $bon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <tr>
       
       
       <td class="text-center"><h3> <span class="blue">N&deg<span><span class="orange"><?php echo e($b->NUMERO_BON_COMMANDE); ?></h3></span></td>
       <td class="text-center blue"><h3><?php echo e(Fdate($b->DATE_COMMANDE)); ?></h3></td>
       <td class="text-center orange"><h3><?php echo e(DateFacture($b->DATE_COMMANDE,$b->DELAIS)); ?></h3></td>
       <td class="text-center blue"><h3><?php echo e(FactMoney($b->MONTANT_TOTAL)); ?></h3></td>
       <td><a href="<?php echo e(route('BonCommande.show',$b->NUMERO_BON_COMMANDE)); ?>"><img src="<?php echo e(asset('images/d.png')); ?>" style="width:50px"></a></td>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </tr>

  
      </table>
      <?php else: ?>
      <br/>
      <p>PAS DE BON DE COMMANDE POUR CE FOURNISSEUR</p>
         <?php endif; ?>      
              
            </div>
        </div>
        
       <br/>
        
          
        

      </div>
       <br/><br/>
      

      
      <div class="row">
        <br/>
        <div class="col-md-offset-0 col-md-2">
        <a href="javascript:history.go(-1);">Annuler</a>
      </div>
    </div>

   
        
        
           
           
          
      </div>
    </div>
</div>
<?php echo $__env->make('Layout/partials/_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>