<?php $__env->startSection('content'); ?>


  <?php echo $__env->make('Layout.partials._nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
<form action="" method="GET">
  <?php echo e(csrf_field()); ?>


<div class="eng_obj">
<div class="container" style="width:1000px">
    <div class="well">


      
      
        <div class="row">
        <div class="col-md-offset-2 col-md-8">
        <h2 class="title text-center">FACTURE ET BON DE COMMANDE <span class="orange"></span></h2>

    </div>
     
        </div>
    <br/><br/><br/>
    

        <div class="row">
            <div class="col-md-offset-1 col-md-8"> 
            <div class="form-group">
    
             
        <table class="table table-bordered" style="width:800px;color:black" >
                 
       <tr>
       
       
       <th class="blue text-center"><h4>BON DE COMMANDES </h4></th>
       <th class="blue text-center"><h4>FACTURE AVANCE </h4></th>
       <th class="blue text-center"><h4>FACTURE SOLDE </h4></th>
       <th class="blue text-center"><h4>MONTANT<br/>FCFA</h4></th>
       <!--<th style="width:50px"></th>-->
       
   </tr>
    <?php  $i=-1 ?>
      <?php $__currentLoopData = $bon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
      <?php  $i++ ?>
   <tr>
       <td class="text-center blue"><?php echo e($b->NUMERO_BON_COMMANDE); ?></td>
       <td class="text-center orange"><a href="<?php echo e(route('Facture.show',ID_FACT($b->NUMERO_BON_COMMANDE))); ?>" class="orange" style="text-decoration:none"><?php echo e(I_AVANCE($b->NUMERO_BON_COMMANDE)); ?></a></td>
       <td class="text-center orange"><a href="<?php echo e(route('Facture.show_',['id'=>ID_FACT_($b->NUMERO_BON_COMMANDE)])); ?>" class="orange" style="text-decoration:none"><?php echo e(I_SOLDE($b->NUMERO_BON_COMMANDE)); ?></a></td>
       <td class="text-center blue"><?php echo e(FactMoney($montant[$i])); ?>

       
   </tr>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
         
              
            </div>
        </div>
        
       <br/>
        
          
        

      </div>
       <br/><br/>
      

      
      <div class="row">
        <br/>
        <div class="col-md-offset-0 col-md-2">
        <a href="javascript:history.go(-1);">Annuler</a>
      </div>
    </div>

   
        
        
           
           
          
      </div>
    </div>
</div>
<?php echo $__env->make('Layout/partials/_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>


<?php echo $__env->make('Layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>