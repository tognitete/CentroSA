<?php $__env->startSection('content'); ?>
<div class="eng_obj">
<div class="container">
    <div class="well">
        <div class="row">
        <div class="col-md-offset-2 col-md-10">
        <h1 class="title">ENREGISTRMENT D'UN FOURNISSEUR</h1>

    </div>
     
        </div>

        <div class="row">
            <div class="col-md-offset-2 col-md-8"> 
            <div class="form-group">
              <label for="nom">Nom</label>
              <input type="text" name="nom" id="nom" class="form-control" placeholder="Nom du fournisseur">

            </div>
        </div>
    </div>

    <div class="row">
            <div class="col-md-offset-2 col-md-8"> 
            <div class="form-group">
              <label for="tel">TEL</label>
              <input type="text" name="tel" id="tel" class="form-control" placeholder="Numero de telephone du fournisseur">
                </div>
        </div>
        
      <div class="row">
        <br/>
        <div class="col-md-offset-5 col-md-2">
        <div class="form-group">
           <button class="btn btn-success ">ENREGISTRER &raquo</button>
           </div>
          </div>
      </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>