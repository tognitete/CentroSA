<?php $__env->startSection('content'); ?>
<div class="eng_obj">
<div class="container">
    <div class="well">
        <div class="row">
        <div class="col-md-offset-3 col-md-10">
        <h1 class="title">ENREGISTRMENT D'UN LIEU</h1>

    </div>
     
        </div>

        <div class="row">
            <div class="col-md-offset-2 col-md-6"> 
            <div class="form-group">
              <label for="designation">Deignation</label>
              <input type="text" name="designation" id="designation" class="form-control" placeholder="Designation du lieu">
             
            </div>
        </div>
        <div class="col-md-offset-0 col-md-2">
          <br/>
         <button class="btn btn-success ">ENREGISTRER &raquo</button> 
    </div>

   
        
        
           
           
          
      </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>