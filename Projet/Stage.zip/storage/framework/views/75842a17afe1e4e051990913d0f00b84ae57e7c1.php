 <nav class="navbar  navbar-static-top  ">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <img src="/images/logo.png" style="width:100px;margin-left:-40px" alt="logo de CENTRO" class="img-rounded">
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
           
            <li class="dropdown">
              <a href="#" class="dropdown-toggle white" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Paramètrage<span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="" class="white">Mise à jour des bons</a></li>
               
                
                
              </ul>

              
             

            <li class="dropdown">
              <a href="#" class="dropdown-toggle white" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Liste<span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="">Facture</a></li>
               
                
                
                
              </ul>
              
               
              
            </li>
            </li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li><a href="#about" class="white">Deconnexion</a></li>
            </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>