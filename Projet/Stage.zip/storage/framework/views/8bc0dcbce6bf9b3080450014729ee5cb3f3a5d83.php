<?php $__env->startSection('content'); ?>
<div class="eng_obj">
<div class="container">
    <div class="well">
        <div class="row">
        <div class="col-md-offset-3 col-md-10">
        <h1 class="title">ENREGISTRMENT D'UNE UTE</h1>

    </div>
     
        </div>

        <div class="row">
            <div class="col-md-offset-2 col-md-6"> 
            <div class="form-group">
              <label for="designation">Deignation</label>
              <input type="text" name="designation" id="designation" class="form-control" placeholder="Nom de l'UTE">
             
            </div>
        </div>
        <div class="row">
        <br/>
        <div class="col-md-offset-5 col-md-2">
        <div class="form-group">
           <input type="submit" name="obj_eng" class="btn btn-success " value="ENREGISTRER &raquo">
           </div>
          </div>
      </div>
      <div class="row">
        <br/>
        <div class="col-md-offset-0 col-md-2">
        <a href="<?php echo e(route('home')); ?>">Annuler</a>
      </div>
    </div>

   
        
        
           
           
          
      </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>