<?php
use App\Bon_Commande\Designation;

if(isset($_GET['rech']) AND !empty($_GET['rech'])){
	$motclef=$_GET['rech'];
  
      $motclef='%'.$motclef.'%';
     
      
  $d=Designation::Where('NOM_DESIGNATION_OBJET','like',$motclef)->get();
}else{
	$d=Designation::all();
}

?>


<html>
<head>
	<title>Recherche</title>
</head>
<body>
	<form method="GET">
		<input type="search" name="rech" id="recherche">
		<input type="submit" value="Valider">
<?php $__currentLoopData = $d; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($desi->NOM_DESIGNATION_OBJET); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</form>
</body>
</html>