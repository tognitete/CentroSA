<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('lieu.store')); ?>" method="POST">
  <?php echo e(csrf_field()); ?>

  <?php echo $__env->make('Layout.partials._nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="eng_obj">
<div class="container">
    <div class="well">


       <img src="/images/logo.png" style="width:100px;margin-left:-20px" alt="logo de CENTRO" class="img-rounded">

        <div class="row">
        <div class="col-md-offset-3 col-md-10">
        <h1 class="title">ENREGISTRMENT D'UN LIEU</h1>

    </div>
     
        </div>

        <div class="row">
            <div class="col-md-offset-2 col-md-8"> 
            <div class="form-group">
              <label for="designation_lieu">Deignation</label>
              <input type="text" name="designation_lieu" id="designation_lieu" class="form-control" placeholder="Designation du lieu">
              <input type="hidden" name="url" value="<?php echo e($url); ?>">
            </div>
        </div>
        
       <br/>
        <div class="col-md-2">
        <div class="form-group">
           <input type="submit" style="height:42px;" name="lieu_eng" class="btn btn-success " value="ENREGISTRER &raquo">
          
           </div>
          </div>
      </div>
      <div class="row">
            <div class="col-md-offset-2 col-md-6"> 
            <div class="form-group">
              <p><?php echo $errors->first('designation_lieu','<span class="help-block err">:message</span>'); ?></p>
            </div>
          </div>
        </div>
      <div class="row">
        <br/>
        <div class="col-md-offset-0 col-md-2">
        <a href="#">Annuler</a>
      </div>
    </div>

   
        
        
           
           
          
      </div>
    </div>
</div>
<?php echo $__env->make('Layout/partials/_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>