<footer class="text-center">
	<p>--&copy; 2017 &middot; CENTRO S.A. <a href="https://centro.tg">voir</a>-- .</p>
 <p><b style="color: rgb(237,104,5)">CONSORTIUM DES ENTREPRISES TROPICALES</b> </p>
</footer>