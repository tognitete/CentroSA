<?php $__env->startSection('content'); ?>


  <?php echo $__env->make('Layout.partials._nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
<form action="" method="GET">
  <?php echo e(csrf_field()); ?>


<div class="eng_obj">
<div class="container">
    <div class="well">


      
      
        <div class="row">
        <div class=" col-md-12">
        <h1 class="title text-center">AFFICHAGE DES INFORMATIONS DU BON DE COMMANDE N&deg<?php echo e($num); ?></h1>

    </div>
     
        </div>
    <br/><br/><br/>
   
 
      <div class="row">
          <div class=" col-md-offset-1 col-md-7" style="">
            
         <div style="border: 2px solid #1c75c8; padding: 3px; background-color: #c5ddf6; -moz-border-radius-topleft: 5px; -moz-border-radius-topright: 5px; -moz-border-radius-bottomright: 5px; -moz-border-radius-bottomleft: 5px;">
<span class="title">BC N&deg</span><span class="orange"><?php echo e($num); ?></span><br/><br/>
<span class="title">Materiaux Commande:</span>
<span class="orange"><?php echo e($desi[0]); ?></span>
<?php for($i=1;$i<count($desi);$i++): ?>
;<span class="orange"><?php echo e($desi[$i]); ?></span>
<?php endfor; ?>
<br/><br/>
<span class="title">Montant Total:</span><span class="orange"><?php echo e($info->MONTANT_TOTAL); ?></span><br/><br/>
<span class="title">Avance:</span> <span class="orange"><?php echo e($info->TAUX_AVANCE); ?>%</span> soit <input type="text" disabled="disabled" value="<?php echo e($cal); ?>"><br/><br/>
<?php if($info->COMMENTAIRE!=null): ?>
<span class="title">observations:</span><span class="orange"><?php echo $info->COMMENTAIRE; ?></span>
<?php endif; ?>
</div>

        </div>
           
          <div class="col-md-1">
                         
              <div class="row">
            <div class=" col-md-8"> 
            <div class="form-group">
              <?php if(($info->TAUX_AVANCE)!=0): ?>
             <button href="/FACTURE_AVANCE?date=<?php echo e($info->DATE_COMMANDE); ?>&num=<?php echo e($num); ?>&montant=<?php echo e($info->MONTANT_TOTAL); ?>&avance=<?php echo e($cal); ?>"  class="btn btn-success"  id="avec" name="avec" style="height:70px"><h4>FACTURE AVEC AVANCE</h4></button>
              <?php endif; ?>
            </div>
           
            </div>
          </div>
           
        <div class="row">
            <div class="col-md-8  "> 
            <div class="form-group">
              <?php if(($info->TAUX_AVANCE==0)): ?>
              <a href="/FACTURE_SANS_AVANCE?date=<?php echo e($info->DATE_COMMANDE); ?>&num=<?php echo e($num); ?>&montant=<?php echo e($info->MONTANT_TOTAL); ?>&avance=<?php echo e($cal); ?>" onclick="return false"  class="btn btn-success" id="sans" name="sans" style="height:70px"><h4>FACTURE SANS AVANCE</h4></a>
              <?php endif; ?>
            </div>
          </div>
        </div>
        
            <div class="row">
            <div class="col-md-offset-2 col-md-5  col-md-push-2 "> 
            <div class="form-group">
             
            </div>
        </div>
        <div class="col-md-offset-2 col-md-3">
            <br/>
          
          </div>
        
    </div>
       
    <div class="row">
            <div class="col-md-offset-2 col-md-8 col-md-push-2"> 
            <div class="form-group">
             
                </div>
        </div>
      </div>
      
      <div class="row">
            <div class="col-md-offset-2 col-md-8 col-md-push-2"> 
            <div class="form-group">
             
                </div>
        </div>
      </div>
      
            <div class="row">
            <div class="col-md-offset-2 col-md-5  col-md-push-2 "> 
            <div class="form-group">
              
            </div>
        </div>
        <div class="col-md-offset-2 col-md-3">
            <br/>
           

          </div>
        
    </div>
   
    <div class="row">
            <div class="col-md-offset-2 col-md-8 col-md-push-2"> 
            <div class="form-group">
             
        </div>
      </div>
        </div>
         
</div>
</div>
<br/><br/><br/>

      

      
      <div class="row">
        <br/>
        <div class="col-md-offset-0 col-md-2">
        <a href="javascript:history.go(-1);">Annuler</a>
      </div>
    </div>

   
        
        
           
           
          
      </div>
    </div>
</div>
<?php echo $__env->make('Layout/partials/_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('Layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>