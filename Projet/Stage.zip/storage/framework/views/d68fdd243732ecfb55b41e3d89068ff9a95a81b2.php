<html>
<head>
	<title></title>
</head>
<script type="text/javascript">
function val(){

	if(!document.getElementById('t1').disabled){

		alert('oui');
	}
}


</script>
<body>
<input type="text" id="t1" ><br/>
<input type="text" id="t2" disabled="disabled"><br/>
<input type="button" value="valider" onclick="val()">
</body>
</html>