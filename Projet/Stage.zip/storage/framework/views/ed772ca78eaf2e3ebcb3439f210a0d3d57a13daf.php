<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title>Title</title>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="/css/commande.css">
<?php echo $__env->make('flashy::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


  <script type="text/javascript" src="/js/Larails.js"></script>


  
 
<?php if($nb>0): ?>
  <script>

  $( function() {
     
   
      

       $("#dialog-confirm" ).dialog({

      resizable: false,
      height: "auto",
      width: 400,
      modal: true,
      buttons: {
       "NON": function() {
          $( this ).dialog( "close" );
          document.getElementById('rep').value="non";
          document.getElementById('objet').selectedIndex=1;
          document.getElementById('designation_objet').value="#";
          document.getElementById('designation_ute').selectedIndex=1;
          $("#form").submit();
        },
        "OUI ": function() {
          $( this ).dialog( "close" );
          document.getElementById('rep').value="oui";
          document.getElementById('objet').selectedIndex=1;
          document.getElementById('designation_objet').value="#";
          document.getElementById('designation_ute').selectedIndex=1;
          $("#form").submit();
        }
      }
    });

  });
 
  </script>
</head>
<body>
   <div id="dialog-confirm" title="ENREGISTREMENT">
  <P class="g">VOTRE ENREGISTREMENT A ETE EFFECTUE</p>
  <p style="color:black"><span class="ui-icon ui-icon-alert yellow" style="float:left; margin:12px 12px 20px 0;"></span><span>VOULEZ-VOUS EFFECTUER UN AUTRE ENREGISTREMENT?</span></p>
</div>

<?php else: ?>
</head>
<body>
<?php endif; ?>


<form action="<?php echo e(route('DesignationObjet.store')); ?>"  method="POST" id="form">
  <?php echo e(csrf_field()); ?>

<?php echo $__env->make('Layout.partials._nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php if(session()->has('message')): ?>
<center>

<div class="alert alert-danger" style="width:250px">
  <?php echo e(session()->get('message')); ?>

</div>
</center>>
<?php endif; ?>

<div class="eng_obj">
<div class="container">
    <div class="well">


<img src="/images/logo.png" style="width:100px;margin-left:-20px" alt="logo de CENTRO" class="img-rounded">


        <div class="row">
        <div class="col-md-offset-1 col-md-10 text-center">
        <h1 class="title">ENREGISTRMENT D'UN ARTICLE</h1>

    </div>
    
        </div>

        
     
              
        <div class="row">
            <div class="col-md-offset-2 col-md-8"> 
            <div class="form-group">
              <label for="designation_objet">Deignation</label>
              <input type="hidden" name="url" value="<?php echo e($url); ?>">
              <input type="text" name="designation_objet" id="designation_objet" class="form-control" value="<?php echo e(old('designation_objet')? old('designation_objet'):''); ?>" placeholder="Designation">
              <p><?php echo $errors->first('designation_objet','<span class="help-block err">:message</span>'); ?></p>
            </div>
        </div>
    </div>

    <div class="row">
            <div class="col-md-offset-2 col-md-6"> 
            <div class="form-group">
              <label for="ute">UTE</label>
              <select id="designation_ute" name="designation_ute" class="form-control">
                <option></option>
                <?php if(!$ute->isEmpty()): ?>
                <?php $__currentLoopData = $ute; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $utes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e(selection_ute($utes->DESIGNATION_UTE,old('designation_ute'))); ?>><?php echo e($utes->DESIGNATION_UTE); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
               
                <?php endif; ?>
              </select>
              <p><?php echo $errors->first('designation_ute','<span class="help-block err">:message</span>'); ?></p>
                </div>
        </div>
        <div class=" col-md-2">
            <br/>
           <a href="<?php echo e(route('ute.create')); ?>"  style="height:40px"class="btn btn-primary form-control">Nouvelle UTE?</a>

          </div>
      </div>
      <div class="row">
        <br/>
        <div class="col-md-offset-5 col-md-2">
        <div class="form-group">
           <input type="submit" name="obj_eng" class="btn btn-success "  value="ENREGISTRER &raquo">

           </div>
          </div>
      </div>
      <div class="row">
        <br/>
        <div class="col-md-offset-0 col-md-2">
        <a href="javascript:history.go(-1);">Annuler</a>
      </div>
    </div>
</div>
 <input type="hidden" id="rep" name="rep" value="defaut">
<input type="hidden" name="nb" value="<?php echo e($nb); ?>">
<?php echo $__env->make('Layout/partials/_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>
</body>
</html>  