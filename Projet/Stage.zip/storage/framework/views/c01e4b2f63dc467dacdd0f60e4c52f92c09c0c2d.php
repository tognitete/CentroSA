<?php
use App\Bon_Commande\Fournisseur;

if(isset($_GET['oui'])){

dd('oui');
}

if(isset($_GET['non'])){
dd('non');
}
?>
<html>
<head>
  <title></title>
</head>
<script type="text/javascript">
function l(){

  alert(document.getElementById('t').value);
}


</script>
<body onload="l()">
<form action="" method="GET">
	<?php echo e(csrf_field()); ?>

<input type="text" id="t">
<input type="submit" value="OUI" name="oui">
<input type="submit" value="NON" name="non">
</form>
</body>
</html>