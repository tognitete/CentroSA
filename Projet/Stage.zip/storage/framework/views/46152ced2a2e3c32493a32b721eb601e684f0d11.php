<?php $__env->startSection('content'); ?>


  <?php echo $__env->make('Layout.partials._nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 

  

<div class="eng_obj">
<div class="container">
    <div class="well">


      
      
        <div class="row">
        <div class=" col-md-12">
        <h1 class="title text-center">COMMANDE IMPAYEE AU FOURNISSEUR <span class="orange"><?php echo e($frs); ?></span></h1>

    </div>
     
        </div>
    <br/><br/><br/>
   
 
      <div class="row">
        <?php if(count($num)!=0): ?>
        <?php for($i=0;$i<count($num);$i++): ?>
        <form action="<?php echo e(route('Rapport.store')); ?>" method="POST">
          <?php echo e(csrf_field()); ?>

          <div class="  col-md-4" style="height:200px">
           
        <?php if((($i+1)%2)==0): ?>    
         <div style="border: 2px solid #1c75c8;height:220px;padding: 3px; background-color:rgb(196,196,196); -moz-border-radius-topleft: 5px; -moz-border-radius-topright: 5px; -moz-border-radius-bottomright: 5px; -moz-border-radius-bottomleft: 5px;" id="banniere" onmouseover="dwn(<?php echo e($i+1); ?>)" onmouseout="outdwn(<?php echo e($i+1); ?>)">
        
        <?php else: ?>
        <div style="border: 2px solid #1c75c8;height:220px;padding: 3px; background-color:rgb(241,221,152); -moz-border-radius-topleft: 5px; -moz-border-radius-topright: 5px; -moz-border-radius-bottomright: 5px; -moz-border-radius-bottomleft: 5px;" id="banniere" onmouseover="dwn(<?php echo e($i+1); ?>)" onmouseout="outdwn(<?php echo e($i+1); ?>)">
        <?php endif; ?>
<span class="title">BC N&deg</span><span class="orange"><?php echo e($num[$i]); ?></span><br/><br/>
<input type="hidden" name="num" value="<?php echo e($num[$i]); ?>">
<span class="title">Materiaux Commande:</span><span class="orange"><?php echo e($desi[$i]); ?></span><br/><br/>
<input type="hidden" name="desi" value="<?php echo e($desi[$i]); ?>">
<span class="title">Montant Total:</span><span class="orange"><?php echo e($montant[$i]); ?></span><br/><br/>
<input type="hidden" name="montant" value="<?php echo e($montant[$i]); ?>">
<span class="title">Avance:</span> <span class="orange"><?php echo e($taux[$i]); ?>%</span> soit <input type="text" disabled="disabled" value="<?php echo e($cal[$i]); ?>"><br/><br/>
<input type="hidden" name="avance" value="<?php echo e($taux[$i]); ?>">
<input type="hidden" name="delais" value="<?php echo e($delais[$i]); ?>">
<input type="hidden" name="cal" value="<?php echo e($cal[$i]); ?>">
<input type="hidden" name="statut" value="impayer">
<?php if($observation[$i]!=null): ?>
<span class="title">observations:</span><span class="orange"><?php echo $observation[$i]; ?></span>
<input type="hidden" name="observation" value="<?php echo e($observation[$i]); ?>">
 <?php endif; ?>
 <div id="<?php echo e($i+1); ?>" class="description">
          Telechargement...
          <input type="submit" class="btn btn-primary dwn" value="Telecharger">
</div>
</div>


        </div>
        </form>
         <?php if(($i+1)%3==0): ?>
     
         </div>
         <div class="row">   
      <br/><br/>
   


      <?php endif; ?>
     
 <?php endfor; ?>      

         
          
    <?php else: ?>

    <h3>Acune commande</h3>

    <?php endif; ?>
        


          
         
</div>
<br/><br/><br/><br/><br/><br/>

      

      
      <div class="row">
        <br/>
        <div class="col-md-offset-0 col-md-2">
        <a href="javascript:history.go(-1);">Annuler</a>
      </div>
    </div>

   
        
        
           
           
          
      </div>
    </div>
</div>
<?php echo $__env->make('Layout/partials/_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('Layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>