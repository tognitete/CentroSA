<div class="row">
            <div class="col-md-offset-5 col-md-2  col-md-push-4"> 
            <div class="form-inline  menu ">
              <label for="nb_eng">Nombre d'enregistrement</label>
              <select id="nb_eng" name="nb_eng" class="form-control"  <?php echo e(desactiver($nb)); ?>>
                <option></option>
                <option <?php echo e(selection($nb,1)); ?>>1</option>
                <option <?php echo e(selection($nb,2)); ?>>2</option>
                <option <?php echo e(selection($nb,3)); ?>>3</option>
                <option <?php echo e(selection($nb,4)); ?>>4</option>
                <option <?php echo e(selection($nb,5)); ?>>5</option>
                <option <?php echo e(selection($nb,6)); ?>>6</option>
                <option <?php echo e(selection($nb,7)); ?>>7</option>
                <option <?php echo e(selection($nb,8)); ?>>8</option>
                <option <?php echo e(selection($nb,9)); ?>>9</option>
                <option <?php echo e(selection($nb,10)); ?>>10</option>
              </select>
            </div>
            <input type="hidden" value="<?php echo e($nb); ?>" name="nb">
            </div>
          </div>