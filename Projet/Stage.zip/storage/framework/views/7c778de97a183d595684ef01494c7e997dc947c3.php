<!DOCTYPE html>
<html>
<head>
	<title>Title</title>
	
	<!-- Latest compiled and minified CSS -->

  <link rel="stylesheet" href="D:/bootstrap-3.3.7-dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="D:/bootstrap-3.3.7-dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

  
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>
<body class="bCmde">

<form action="<?php echo e(route('pdfTransfert.store')); ?>" method="POST">
   <?php echo e(csrf_field()); ?>

<style type="text/css">
<?php echo $__env->make('pdf.bonCommande', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('pdf.bootstrap_theme', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('pdf.bootstrap', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</style>

  <div class="">
    <div class="row">
    	<div class="col-xs-2">
    		<br/><br/><br/>
    		<img src="/images/logo.png" style="width:210px;margin-left:40px;" alt="logo de CENTRO" class="img-rounded">
    	</div>
    	<div class="col-xs-offset-0 col-xs-2" style="width:130px;margin-left:80px;">
    		<br/><br/><br/><br/><br/><br/><br/>
    		Connsortium
            Des Entreprises
            Tropicales    	
            </div>
            <div class="col-xs-2 col-xs-push-6" style="">
              NIF:1000116424<br/>                
              189,Rue Atoeta<br/>
              TOKOIN Doumasséssé<br/>
              B.P:20744 Lomé-TOGO<br/>
              Tél:(00228) 22 22 56 83<br/>
              &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp93 19 75 16<br/>
              Fax:(00228)22 22 62 52<br/>
              E-mail:info@centro.tg<br/>
               &nbsp &nbsp &nbsp &nbsp &nbsp &nbspcentro_tg@yahoo.fr<br/>
              <span style="margin-right:40%;">http://www.centro.tg</span>                  
            </div>
    </div>
    <p style="margin-left:10px;">SOCIETE ANONYME - S.A. au capital social de 636 300 000</p>
    <br/>
    <div class="barre"></div>
    <br/><br/>
    <div class="row">
    	<h3 class="title text-center">BON DE TRANSFERT N&deg<?php echo e($num); ?>/PDG/DAA/CAA<?php echo e($tete); ?>/<?php echo e($y); ?></h3>
    </div>
    <br/><br/>
    <div class="row">
    	<h3><span class="title" style="margin-left:11%;">OBJET</span> :<?php echo e($objet); ?></h3>
      <input type="hidden" value="<?php echo e($objet); ?>" name="objet">
    </div>
    <div class="row">
    	<h3><span class="title" style="margin-left:11%;">PROVENANACE</span> :<?php echo e($provenance); ?></h3>
      <input type="hidden" value="<?php echo e($provenance); ?>" name="provenance">
    </div>
    <div class="row">
    	<h3><span class="title" style="margin-left:11%;">DESTINATION</span> :<?php echo e($destination); ?></h3>
      <input type="hidden" value="<?php echo e($destination); ?>" name="destination">
    </div>
    <br/><br/>
    <div class="row">
    	<div class="col-xs-offset-1 col-xs-10">
    	<table>
    		<tr>
    			<th class="text-center">DESIGNATION</th>
    			<th class="text-center">UTE</th>
    			<th class="text-center">QUANTITE</th>
    		</tr>
        <?php for($i=0;$i<count($designation);$i++): ?>
    		<tr>
    			<td class="text-center"><?php echo e($designation[$i]); ?></td>
          <input type="hidden" value="<?php echo e($designation[$i]); ?>" name="<?php echo e(delSpace_Echo($designation[$i])); ?>">
          <td class="text-center"><?php echo e($ute[$i]); ?></td>
          <input type="hidden" value="<?php echo e($ute[$i]); ?>" name="<?php echo e(delSpace_Echo($designation[$i])); ?>ute">
          <td class="text-center"><?php echo e($qte[$i]); ?></td>
          <input type="hidden" value="<?php echo e($qte[$i]); ?>" name="<?php echo e(delSpace_Echo($designation[$i])); ?>qte">
    		</tr>
        <?php endfor; ?>
    	</table>
    </div>

</div>
<br/>
<div class="row">
<div class="col-xs-offset-1 col-xs-6">
<?php if($commentaire==null || $commentaire==""): ?>
<br/><br/><br/><br/>
<?php else: ?>
<?php echo $commentaire; ?>

<?php endif; ?>
<input type="hidden" value="<?php echo e($commentaire); ?>" name="commentaire">  
</div>
</div>
<div class="row">
	<div class="col-xs-3 col-xs-push-7">
		<?php echo e($lieu); ?>, <?php echo e($j); ?> <?php echo e($m); ?> <?php echo e($y); ?><br/>
    <input type="hidden" value="<?php echo e($lieu); ?>" name="lieu">
    <input type="hidden" value="<?php echo e($tete); ?>" name="tete">
    <input type="hidden" value="<?php echo e($j); ?>" name="j">
    <input type="hidden" value="<?php echo e($m); ?>" name="m">
    <input type="hidden" value="<?php echo e($y); ?>" name="y">
		Le Président Directeur Général,<br/>
		<br/><br/><br/><br/>
		<h4 class="title">Kpatcha BASSAYI</h4>
	</div>
	</div>
	<br/><br/><br/><br/><br/><br/><br/><br/>
	
  
  
</div>
<div>
<div class="col-md-offset-2 col-md-2">
        <div class="form-group">

           
           <a href="<?php echo e(route('BonTransfert.create',['user'=>$user])); ?>" class="btn btn-default" style="height:50px;width:100px">REFAIRE</a>
           </div>
          </div>
<div class="col-md-offset-1 col-md-2">
        <div class="form-group">

           <input type="submit" name="telecharger" class="btn btn-default "  style="height:50px" value="TELECHARGER">
           </div>
          </div>
          <div class="col-md-offset-1 col-md-2">
        <div class="form-group">

           
           <a href="<?php echo e(route('acueil',['user'=>$user])); ?>" class="btn btn-default" style="height:50px;width:100px">QUITTER</a>
           </div>
          </div>
        </div>
<script src="//code.jquery.com/jquery.js"></script>

<input type="hidden" value="<?php echo e($num); ?>" name="num">
<input type="hidden" id="user" name="user" value="<?php echo e($user); ?>">
<?php echo $__env->make('flashy::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



</form>
</body>
</html>