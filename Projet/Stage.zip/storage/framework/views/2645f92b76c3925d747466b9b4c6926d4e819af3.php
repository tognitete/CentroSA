<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('fournisseur.store')); ?>" method="POST">
  <?php echo e(csrf_field()); ?>

  <?php echo $__env->make('Layout.partials._nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="eng_obj">
<div class="container">
    <div class="well">


   <img src="/images/logo.png" style="width:100px;margin-left:-20px" alt="logo de CENTRO" class="img-rounded">

        <div class="row">
        <div class="col-md-offset-2 col-md-10">
        <h1 class="title">ENREGISTRMENT D'UN FOURNISSEUR</h1>

    </div>
     
        </div>

        <div class="row">
            <div class="col-md-offset-2 col-md-8"> 
            <div class="form-group">
              <label for="nom_fournisseur">Nom</label>
              <input type="hidden" name="url" value="<?php echo e($url); ?>">
              <input type="text" name="nom_fournisseur" id="nom_fournisseur" class="form-control" placeholder="Nom du fournisseur">
              <p><?php echo $errors->first('nom_fournisseur','<span class="help-block err">:message</span>'); ?></p>
            </div>
        </div>
    </div>

    <div class="row">
            <div class="col-md-offset-2 col-md-8"> 
            <div class="form-group">
              <label for="tel_fournisseur">TEL</label>
              <input type="text" name="tel_fournisseur" id="tel_fournisseur" class="form-control" placeholder="Numero de telephone du fournisseur">
              <p><?php echo $errors->first('tel_fournisseur','<span class="help-block err">:message</span>'); ?></p> 
                </div>
        </div>
        
      <div class="row">
        <br/>
        <div class="col-md-offset-5 col-md-2">
        <div class="form-group">
           <input type="submit" name="obj_eng" class="btn btn-success " value="ENREGISTRER &raquo">
           </div>
          </div>
      </div>
      <div class="row">
        <br/>
        <div class="col-md-offset-0 col-md-2">
        <a href="#">Annuler</a>
      </div>
    </div>
    </div>
</div>
<?php echo $__env->make('Layout/partials/_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>