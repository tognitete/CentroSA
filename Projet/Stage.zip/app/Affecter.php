<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Affecter extends Model
{
    protected $fillable = ['ID_DESTINATION','NUMERO_BON_COMMANDE'];
}
