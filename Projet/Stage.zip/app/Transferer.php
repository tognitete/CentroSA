<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Transferer extends Model
{
    protected $fillable = ['ID_DESTINATION','NUMERO_BON_TRANSFERT'];
}
