<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Division extends Model
{
    protected $fillable = ['ID_DIVISION','DESIGNATION_DIVISION'];
}
