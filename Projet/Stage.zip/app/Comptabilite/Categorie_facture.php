<?php

namespace App\Comptabilite;

use Illuminate\Database\Eloquent\Model;

class Categorie_facture extends Model
{
    //
}
