<?php

namespace App\Comptabilite;

use Illuminate\Database\Eloquent\Model;

class Type_Facture extends Model
{
    //
}
