<?php

namespace App\Bon_Commande;

use Illuminate\Database\Eloquent\Model;

class Type_bon_de_commande extends Model
{
    //
}
