<?php

namespace App\Bon_Commande;

use Illuminate\Database\Eloquent\Model;

class Lieu_ou_a_lieu_bon_commande extends Model
{
    protected $fillable =["DESIGNATION_LIEU"];
}
