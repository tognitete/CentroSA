<?php

namespace App\Bon_Commande;

use Illuminate\Database\Eloquent\Model;

class Ute extends Model
{
     protected $fillable = ['DESIGNATION_UTE'];
}
