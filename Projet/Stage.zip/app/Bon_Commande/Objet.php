<?php

namespace App\Bon_Commande;

use Illuminate\Database\Eloquent\Model;

class Objet extends Model
{
    protected $fillable = ['NOM_OBJET'];
}
