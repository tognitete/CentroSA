<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Role extends Model
{
    protected $fillable = ['ID_ROLE','DESIGNATION_ROLE'];
}
